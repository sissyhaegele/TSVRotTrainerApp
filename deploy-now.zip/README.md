﻿# TSV 1905 Rot e.V. - Trainer & Stundenplanung

Web-App zur Verwaltung von Trainern und Trainingsstunden der Turnabteilung.

## 🌐 Live Demo

**https://sissyhaegele.github.io/TSVRotTrainerApp/**

## 📋 Features

- Dashboard mit Übersicht
- Kursverwaltung  
- Trainerverwaltung
- Responsive Design
- Datenspeicherung im Browser
- Mobile-optimiert

## 🛠️ Technologie

- React
- Tailwind CSS
- GitHub Pages
- LocalStorage für Datenpersistenz

## 👥 Für TSV 1905 Rot e.V. Mitglieder

Die App ist unter folgendem Link erreichbar:
https://sissyhaegele.github.io/TSVRotTrainerApp/

## 👩‍💻 Entwicklung

**Entwickelt von:** Sissy Hägele  
**Repository:** https://github.com/sissyhaegele/TSVRotTrainerApp  
**Kontakt:** sissy.haegele@tsvrot.de

---

## ©️ Copyright & Lizenz

**Copyright © 2024 Sissy Hägele. Alle Rechte vorbehalten.**

Diese Software wurde exklusiv für den TSV 1905 Rot e.V. entwickelt.
Die Nutzung, Vervielfältigung oder Verteilung ohne ausdrückliche 
schriftliche Genehmigung von Sissy Hägele ist untersagt.

**Entwickelt mit ❤️ von Sissy Hägele für TSV 1905 Rot e.V.**  
**Kontakt: sissy.haegele@tsvrot.de**
