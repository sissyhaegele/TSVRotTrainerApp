﻿<?php
phpinfo();
?>
