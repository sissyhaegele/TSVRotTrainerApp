﻿<?php
// api.php - TSV 1905 Rot e.V. REST API
// © 2024 Sissy Hägele

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');

require_once 'config.php';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    $action = $_GET['action'] ?? 'status';
    
    switch($action) {
        case 'status':
            echo json_encode([
                'status' => 'OK',
                'api' => 'TSV 1905 Rot e.V. API v1.0',
                'copyright' => '© 2024 Sissy Hägele',
                'timestamp' => date('Y-m-d H:i:s')
            ]);
            break;
            
        case 'dashboard':
            $sql = "SELECT 
                    (SELECT COUNT(*) FROM courses) as total_courses,
                    (SELECT COUNT(*) FROM trainers) as total_trainers,
                    (SELECT COUNT(*) FROM courses c WHERE 
                        (SELECT COUNT(*) FROM course_trainers WHERE course_id = c.id) >= c.required_trainers
                    ) as fully_staffed";
            
            $result = $conn->query($sql);
            echo json_encode($result->fetch_assoc());
            break;
            
        case 'courses':
            $sql = "SELECT c.*, 
                    GROUP_CONCAT(t.name SEPARATOR ', ') as trainer_names
                    FROM courses c
                    LEFT JOIN course_trainers ct ON c.id = ct.course_id
                    LEFT JOIN trainers t ON ct.trainer_id = t.id
                    GROUP BY c.id
                    ORDER BY c.day_of_week, c.time";
            
            $result = $conn->query($sql);
            $courses = [];
            while($row = $result->fetch_assoc()) {
                $courses[] = $row;
            }
            echo json_encode($courses);
            break;
            
        case 'trainers':
            $sql = "SELECT * FROM trainers ORDER BY name";
            $result = $conn->query($sql);
            $trainers = [];
            while($row = $result->fetch_assoc()) {
                $trainers[] = $row;
            }
            echo json_encode($trainers);
            break;
            
        default:
            http_response_code(404);
            echo json_encode(['error' => 'Unknown action']);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Server error',
        'message' => $e->getMessage()
    ]);
}
